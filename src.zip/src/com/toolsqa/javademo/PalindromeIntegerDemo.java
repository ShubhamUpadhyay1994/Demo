package com.toolsqa.javademo;

public class PalindromeIntegerDemo {

	public static void main(String args[]) {

		int sum = 0, temp, rev;
		int n = 671;
		temp = n;
		while (n > 0) {
			rev = n % 10;
			sum = sum * 10 + rev;
			n = n / 10;
			System.out.println(" n is" + n);
		}
		if (temp == sum) {
			System.out.println("palindrome ");
		} else {
			System.out.println(" not a palindrome");
		}

		// armstrong number

		int num = 371, arm = 0, temp1, rs;
		temp1 = num;
		while (num > 0) {
			rs = num % 10;
			arm = arm + (rs * rs * rs);
			num = num / 10;
		}

		if (temp1 == arm) {
			System.out.println("armstrong number" + arm);
		} else {
			System.out.println("not a armstrong" + arm);
		}
	}
}
