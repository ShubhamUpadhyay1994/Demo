package com.toolsqa.javademo;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class StringReverse {

	public static void main(String args[]) {
		char a[] = new char[10];
		String str = "artik";
		String ts = "";
		char[] str1 = str.toCharArray();

		StringBuffer stringReverse = new StringBuffer();
		for (int i = str.length() - 1; i >= 0; i--) {
			// stringReverse= stringReverse.append(str.charAt(i));
			System.out.print(str.charAt(i));
			ts = ts + str.charAt(i);
			System.out.println("***********" + ts.hashCode());
			// a[i]=ts;
		}

		System.out.println("reveresed string is " + ts);
		System.out.println("Reverse string using list");

		String reverse = "You got offer of 6 lacs bro";
		char hello[] = reverse.toCharArray();
		List<Character> list = new ArrayList<Character>();
		for (Character c : hello) {
			list.add(c);
		}
		Collections.reverse(list);
		ListIterator li = list.listIterator();
		while (li.hasNext()) {
			System.out.print(li.next());
		}
	}

}
