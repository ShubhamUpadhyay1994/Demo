package com.toolsqa.javademo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

public class ListDuplicateElementDemo {

	public static void main(String args[]) {
		ArrayList<String> element = new ArrayList<String>();
		System.out.println("size of arraylist"+element.size());
		element.add("pawan");
		element.add("rajan");
		element.add("aniket");
		element.add("hare");
		element.add("amit");
		element.add("shivam");
		element.add("pawan");
		element.add("hare");
		element.add("amit");
		element.add("alok");

		HashMap<String, Integer> hashmap = new HashMap<String, Integer>();
		ArrayList<String> eleList = new ArrayList<String>(element);
		for (String ele : element) {
			int counter = 0;
			for (String child : eleList) {
				if (ele.equalsIgnoreCase(child)) {
					counter++;
				}
			}
			hashmap.put(ele, counter);
		}

		
		System.out.println("Itearor to iterate a list");
		Iterator< String> itr=element.iterator();
		while(itr.hasNext()){
			String check=itr.next();
			if(check=="amit"){
				itr.remove();
			}
			System.out.println(itr.next());
		}
		System.out.println("use enumeration to inerate over list");
		Enumeration<String> readData = Collections.enumeration(element);
		while (readData.hasMoreElements()) {
			System.out.println(readData.nextElement());
		}

		System.out.println("Read map using keyset");
		// read map
		for (String read : hashmap.keySet()) {
			System.out.println("Key is  " + read + " " + hashmap.get(read));
		}

	/*	System.out.println("remove duplicate element from list");
		HashSet<String> readUnique = new HashSet<String>(element);
		for (String str : readUnique) {
			System.out.println("unique value is " + str);
		}*/

		System.out.println("2nd way to read map data using EntrySet");
		for (Map.Entry<String, Integer> read : hashmap.entrySet()) {
			System.out.println("Key -> " + read.getKey() + " value ->"
					+ read.getValue());
		}
	}
}
