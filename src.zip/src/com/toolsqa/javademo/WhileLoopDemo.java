package com.toolsqa.javademo;
import java.util.Scanner;

public class WhileLoopDemo {

	public static void main(String args[]) {
		/*Scanner sc = new Scanner(System.in);
		int size = 0, i = 0;

		System.out.println("enter the size of array");
		size = sc.nextInt();
		int arr[] = new int[size];
		// read array
		for (i = 0; i < size; i++) {
			System.out.println("enter array" + i);
			arr[i] = sc.nextInt();
		}
		System.out.println("number entered successfully");

		while (i <= size) {
			System.out.println(" array element is " + arr[i]);
			i++;
		}*/
		int i=0,j=0,sum=0,k=1,m=0;
		
		int arr[] = new int[10];
		while(i<10){
			arr[i]=k;
			System.out.println("assign array"+arr[i]);
			i++;
			k++;
			
		}
		i=0;
		while(i<10){
			if((arr[i]%2)==0){
				 sum = sum+arr[i];
			}
			i++;
		System.out.println("sum of even no");
		}
		System.out.println("sum is "+sum);

		do{
			System.out.println("do while");
			j++;
		}while(j>100);
	}
}
