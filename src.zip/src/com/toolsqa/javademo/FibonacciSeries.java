package com.toolsqa.javademo;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int first, second, sum = 0;

		System.out.println("enter no from user");

		first = sc.nextInt();
		second = sc.nextInt();

		System.out
				.println("Enter no of times you want to find fibonacci series");
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			sum = first + second;
			System.out.println(" fibonacci series is " + sum);
			first = second;
			second = sum;
		}

	}
}
