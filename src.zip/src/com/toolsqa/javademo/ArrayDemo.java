package com.toolsqa.javademo;

public class ArrayDemo {

	public static void main(String args[]) {

		//2 D array
		int a[][] = new int[][] {{99,89,76,45,32,23}, { 1, 2 ,3,6,7},  { 5, 6, 9},{12,23,34,8,7,6},{54,56,87,89,76,45} };

		System.out.println("array size is");
		for (int i = 0; i<a.length; i++) {
			for (int j = 0; j<a[i].length; j++) {
				System.out.print(a[i][j]+" ");
			}
			
			System.out.println(" ");
		}
		
		System.out.println(" _________________________3 D Array_______________________");
		//3 D array
		
		double array3D[][][]= new double[][][]{
				{
					{1,2,3,4,5},
					{6,7,8,9,10},
					{11,12,13,14,15},
				},
				{
					{21,22,23,24,25},
					{26,27,28,29,30},
					{31,32,33,34,35},
				}
		};
		
		for(int i=0;i<array3D.length;i++){
		//	System.out.println(" array3D.length "+array3D.length);
			for(int j=0;j<array3D[i].length;j++){
			//	System.out.println("array3D[i].length "+array3D[i].length);
				for(int k=0;k<array3D[i][j].length;k++){
				//	System.out.println("array3D[i][j].length "+array3D[i][j].length);
					System.out.print(array3D[i][j][k]+" ");
				}
				System.out.println(" ");
			}
			System.out.println(" ");
		}
	}
}
