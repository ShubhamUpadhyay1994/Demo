package com.toolsqa.javademo;

import java.util.Scanner;

public class ForLoopDemo {

	public static void main(String args[]) {

		int size = 0, i, j, p = 40;
		int q = 1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		size = sc.nextInt();
		// System.out.println("array size " + size);
		int arr[] = new int[size];

		// create array and assign value
		for (i = 0; i < size; i++) {
			arr[i] = p;
			p++;
			System.out.println("array element is" + arr[i]);
		}

		// ascending order using two loop 
		//For discending order just change the if statement
		for (i = 0; i < size; i++) {
			System.out.println("i is " + i);
			for (j = i + 1; j < size; j++) {
				int c = arr[i];

				if (arr[i] > arr[j]) {
					arr[i] = arr[j];
					arr[j] = c;

				}

			}

		}

		// display sort array

		for (i = 0; i < size; i++) {
			System.out.println("value is " + arr[i]);
		}
	}
}
