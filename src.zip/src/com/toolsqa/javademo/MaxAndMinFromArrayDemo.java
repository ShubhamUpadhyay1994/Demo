package com.toolsqa.javademo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class MaxAndMinFromArrayDemo {

	static int x = 1;

	public static void main(String args[]) {
		int arr[] = new int[] { 5, 7, 9, 9, 3, 4, 5, 2, 12, 56, 56, 56, 78, 78,
				78, 67 };
		// get repeated element from loop and highest and minimum value and
		// count the value that us repeated
		int max = arr[0], min = arr[0];
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] > max) {
				max = arr[i];
			}
			if (arr[i] < min) {
				min = arr[i];
			}
		}

		System.out.println(" max and min value is" + max + "min is " + min);

		int repeat[] = new int[10];

		List<Integer> list = new ArrayList<Integer>();
		Set<Integer> slist = new TreeSet<Integer>();
		Map<Integer, Integer> duplicate = new TreeMap<Integer, Integer>();

		for (int i = 0; i < arr.length; i++) {
			x = 1;
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j] && i != j) {
					slist.add(arr[i]);
					++x;
					// list.add(x);
				}

			}
			list.add(x);
		}

		for (Integer rst : list) {
			System.out.println("repeated element  " + rst);
		}
	}

}
