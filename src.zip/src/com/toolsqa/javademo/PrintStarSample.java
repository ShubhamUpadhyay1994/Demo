package com.toolsqa.javademo;

public class PrintStarSample {
	public static void main(String args[]) {
		for(int i=3;i>=1;i--){
			//System.out.print("i is "+i);
			for(int j=i;j>=0;j--){
			//	System.out.print("j is "+j);
				System.out.print("*");
		
					}
			System.out.println( " ");

		}
	
	System.out.println("______________________________________");
	for(int i=0;i<4;i++){
		for(int j=1;j<=i;j++){
			System.out.print("X");
		}
		System.out.println("  ");
	}
}
}