package com.poi.collection;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFRomExcel {

	// @SuppressWarnings("deprecation")
	public static void main(String args[]) throws InvalidFormatException,
			IOException {
		// get file

		FileInputStream fileInput = new FileInputStream(new File(
				"H:/CandidateShubham.xlsx"));

		// create workbook
		XSSFWorkbook workbook = new XSSFWorkbook(fileInput);

		// create sheet
		XSSFSheet sheet = workbook.getSheetAt(0);

		// iterate row
		Iterator<Row> interatorRow = sheet.iterator();
		DataFormatter dataFormatter = new DataFormatter();
		while (interatorRow.hasNext()) {
		
			// get next row from sheet
			Row nextRow = interatorRow.next();
			// iterate cell of above row
			Iterator<Cell> cellIterator = nextRow.cellIterator();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				String cellValue = dataFormatter.formatCellValue(cell);
				
				if(cellValue.equals("testuser")){
					//cell.get
				}
				System.out.print(cellValue + "\t");
			}
			System.out.println();
		}

	}
}
