package com.poi.collection;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class WriteIntoExcelUsingApachePoi {

	public static void main(String[] args) {

		XSSFWorkbook workbook = new XSSFWorkbook();

		XSSFSheet sheet = workbook.createSheet("Employee");

		Object[][] employee = { {" 1", "Ramanand", "TCS", "BKC" },
				{ "2", "Hare", "TCS", "Andheri" }, 
				{ "3", "Amit", "TCS", "Pune " },
				{ "4", "Amrita", "TCS", "Chennai" },
				{ "5", "Karishma", "TCS", "Pune" },

		};

		int rowCount = 0;
		for (Object[] rowData : employee) {
			Row row = sheet.createRow(++rowCount);
			int columnCount =0;
			for(Object field :rowData){
				Cell cell =row.createCell(++columnCount);
				if(field instanceof String){
					cell.setCellValue((String)field);
					System.out.println(field);
				}
				if(field instanceof Integer){
					cell.setCellValue((Integer)field);
				}
			}
		}
		
		try {
			FileOutputStream fileOutput = new FileOutputStream("Employee.xlsx");
			try {
				workbook.write(fileOutput);
				fileOutput.close();
				System.out.println("written file");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
