package com.poi.collection;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;

public class CreateSheet {

	public static void main(String args[]) throws IOException {
		// Blank workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		// create sheet
		XSSFSheet sheet = workbook.createSheet("Employee Sheet");

		// Data needs to be written
		Map<String, Object[]> data = new TreeMap<String, Object[]>();

		data.put("1", new Object[] { "ID", "Name", "Lastname" });
		data.put("2", new Object[] { "1", "Shubham", "Upadhyay" });
		data.put("3", new Object[] { "3", "Ajay", "SIngh" });

		// Iterator over data and write to sheet
		Set<String> KeySet = data.keySet();
		int rownum = 0;

		for (String key : KeySet) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}

		// write the workbook in file system
		FileOutputStream file = null;
		try {
			file = new FileOutputStream("H:/employee.xlsx");
			workbook.write(file);

			file.close();

			System.out.println("written successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
