package com.poi.collection;
import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelForLoop {

	public static void main(String args[]) {

		try {
			readExcel();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String readExcel() throws IOException, AWTException {
		FileInputStream file = new FileInputStream(new File(
				"H:/CandidateShubham.xlsx"));

		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(1);

		// get rowcount and column count from a sheet

		// rowcount
		int row = sheet.getLastRowNum();
		int column = sheet.getRow(2).getLastCellNum();

		int r1 = sheet.getPhysicalNumberOfRows();
		int c1 = sheet.getRow(0).getPhysicalNumberOfCells();

		System.out.println("last row and column"+row + "   "+column);
		System.out.println("physicalcell row and column method "+r1 + "   "+c1);
		for (int m = 0; m < row; m++) {
			Row readRow = sheet.getRow(m);
			int columnLoop=readRow.getPhysicalNumberOfCells();
			if (readRow != null)
				for (int n = 0; n < columnLoop; n++) {

					Cell cell = readRow.getCell(n);
					if (cell != null) {
						System.out.println(cell.getStringCellValue());
					}
				}

		}
		return null;
	}
}
