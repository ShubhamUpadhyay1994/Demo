package com.poi.collection;


import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchWindowAndScrollDemo {

	static WebDriver driver;
	static WebElement foundWcsites;

	public static void hitUrl(String url) {

		System.setProperty(
				"webdriver.chrome.driver",
				"H:/Software/SeleniumHQ/Selenium WebDriver/Chrome Index of 2.3/chromedriver_win32/chromedriver.exe");
		// driver.manage().window().maximize();

		driver = new ChromeDriver();
		driver.navigate().to(url);
		// driver.manage().window().maximize();

	}

	public static void waitForWeblogicPage() {
		driver.findElement(By.cssSelector("a[href='//www.w3schools.com']"));
		// driver.navigate().back();

	}

	//switch demo
	public static void switchWindow() {
		
		//scroll demo

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,600)");
		WebElement element = driver
				.findElement(By
						.xpath("//a[contains(@href,'tryit.asp?filename=tryhtml_default')]"));
		String parent = driver.getWindowHandle();

		element.click();
		Set<String> child = driver.getWindowHandles();
		for (String ch : child) {
			driver.switchTo().window(ch);
		
			
		}
		/*
		 * String childWindow = child.iterator().next();
		 * driver.switchTo().window(childWindow);
		 */}

	public static void main(String args[]) {
		String url = "https://www.w3schools.com/html/";
		hitUrl(url);
		waitForWeblogicPage();
		switchWindow();
	}
}
