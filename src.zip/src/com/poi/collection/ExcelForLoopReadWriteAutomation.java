package com.poi.collection;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExcelForLoopReadWriteAutomation {

	static WebDriver driver;
	static int i = 1;
	static String technology, check;
	static Map<String, String> map = new HashMap<String, String>();

	static void readExcel() throws InvalidFormatException, IOException {
		FileInputStream file = new FileInputStream(new File(
				"H:/CandidateShubham.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		System.out.println(" hellow");
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rows = sheet.getPhysicalNumberOfRows();
		int column = sheet.getRow(0).getPhysicalNumberOfCells();

		for (int i = 0; i <= rows; i++) {
			Row row = sheet.getRow(i);
			if (row != null) {
				for (int j = 0; j <= column; j++) {
					Cell cell = row.getCell(j);
					if (cell != null)
						System.out.print(cell.getStringCellValue() + "  ");
					technology = row.getCell(0).getStringCellValue();
					check = row.getCell(3).getStringCellValue();

					if (check.equalsIgnoreCase("y")) {
						map.put(technology, check);
					}

				}
				System.out.println("  ");

			}
		}

	}

	static void checkTechnology() throws AWTException, IOException {
		for (String tech : map.keySet()) {
			System.out.println("added in map   " + tech);
			searchTechnology(tech);
			String result = waitForResult();
			String str[] = result.split(" ");
			for (String x : str) {
				System.out.println("Splitted text is " + x);
			}

			writeExcel(tech, str[1], str[3] + str[4]);
			// clearSearchBox(tech);

		}
	}

	public static void writeExcel(String technology, String result, String time)
			throws IOException {
		int resultindex = 0, timeIndex = 0;
		FileInputStream file = new FileInputStream(new File(
				"H:/CandidateShubham.xlsx"));
		Workbook workbook = new XSSFWorkbook(file);
		Sheet sheet = workbook.getSheetAt(0);
		int row = sheet.getPhysicalNumberOfRows();
		int column = sheet.getRow(0).getPhysicalNumberOfCells();
		Row r1 = sheet.getRow(0);
		
		// For loop to get header of excel
		for (int i = 0; i < column; i++) {
			String value = r1.getCell(i).getStringCellValue();
			if (value.equalsIgnoreCase("Result")) {
				resultindex = i;

			}
			if (value.equalsIgnoreCase("Time")) {
				timeIndex = i;
			}
			System.out.println(" index value is " + resultindex + " "
					+ timeIndex);
		}
		
		//Write excel
		for (int i = 0; i <= row; i++) {
			Row getRow = sheet.getRow(i);
			if (getRow != null) {
				String technoFromExcel = getRow.getCell(0).getStringCellValue();
				if (technoFromExcel.equals(technology)) {
					for (int j = 1; j < column; j++) {
						sheet.getRow(i).createCell(resultindex)
								.setCellValue(result);
						sheet.getRow(i).createCell(timeIndex)
								.setCellValue(time);
					}
				}
			}

		}

		FileOutputStream out = new FileOutputStream(new File(
				"H:/CandidateShubham.xlsx"));
		workbook.write(out);
		workbook.close();
	}

	public static void launchUrl(String url) {

	/*	System.setProperty(
				"webdriver.chrome.driver",
				"H:/Software/SeleniumHQ/Selenium WebDriver/Chrome Index of 2.3/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();*/
		String service="H:/Software/SeleniumHQ/Selenium WebDriver/2.53/IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver", service);
		driver = new InternetExplorerDriver();
		driver.get(url);
	}

	public static void searchTechnology(String enterText) throws AWTException {
		WebElement searchBox = driver.findElement(By.id("lst-ib"));
		searchBox.sendKeys(enterText);

		if (i == 1) {
			WebElement clickOnSearch = driver.findElement(By
					.xpath("//input[@name='btnK']"));

			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_TAB);
			// Actions action = new Actions(driver);
			// action.contextClick(clickOnSearch);
			clickOnSearch.click();
			i++;
		} else {
			WebElement resultSearch = driver.findElement(By.id("mKlEF"));
			String resultPage = resultSearch.getAttribute("id");
			// System.out.println(" result page id is " + resultPage);
			resultSearch.click();
		}

	}

	public static String waitForResult() {
		WebElement element = driver.findElement(By.id("lst-ib"));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(element));
		WebElement result = driver.findElement(By.id("resultStats"));
		System.out.println("result is    " + result.getText());
		element.clear();
		return result.getText();

	}

	public static void main(String args[]) throws InvalidFormatException,
			IOException, AWTException {
		readExcel();
		launchUrl("https://www.google.com");
		checkTechnology();

	}
}
