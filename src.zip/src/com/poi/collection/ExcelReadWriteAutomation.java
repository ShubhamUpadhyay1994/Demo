package com.poi.collection;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExcelReadWriteAutomation {
	static WebDriver driver;
	static String url = "https://www.google.com";
	static int y = 0;

	public static void readExcel() throws IOException, AWTException {
		FileInputStream file = new FileInputStream(new File(
				"H:/candidateSheet.xlsx"));

		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);

		// get rowcount and column count from a sheet

		// rowcount
		int row = sheet.getPhysicalNumberOfRows();
		int column = sheet.getRow(0).getPhysicalNumberOfCells();
		
		for(int m=0;m<=row;m++){
			for(int n =0;n<=column;n++){
				System.out.println(sheet.getRow(m).getCell(n).getStringCellValue());
			}
		}

		for (int i = 0; i <= 1; i++) {
			String check = sheet.getRow(i).getCell(3).getStringCellValue();
			System.out.println("check value is  " + check);
			if (check.equalsIgnoreCase("y")) {
				String techno = sheet.getRow(i).getCell(0).getStringCellValue();
				System.out.println("techno string is  " + techno);

				serachString(techno);
				String result = waitForResult();
				// set cell value
				sheet.getRow(i).createCell(1).setCellValue(result);
				sheet.getRow(i).createCell(2).setCellValue(result);

				FileOutputStream fout = new FileOutputStream(new File(
						"H:/candidateSheet.xlsx"));
				// write excel
				workbook.write(fout);
				workbook.close();
				// clearSearchBox(techno);

			}
		}
	}

	public static void launchUrl(String url) {

		System.setProperty(
				"webdriver.chrome.driver",
				"H:/Software/SeleniumHQ/Selenium WebDriver/Chrome Index of 2.3/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(url);
	}

	public static void serachString(String enterText) throws AWTException {
		WebElement searchBox = driver.findElement(By.id("lst-ib"));
		searchBox.sendKeys(enterText);
		WebElement clickOnSearch = driver.findElement(By
				.xpath("//input[@name='btnK']"));

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		// Actions action = new Actions(driver);
		// action.contextClick(clickOnSearch);
		clickOnSearch.click();
	}

	public static String waitForResult() {
		WebElement element = driver.findElement(By.id("lst-ib"));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.visibilityOf(element));
		WebElement result = driver.findElement(By.id("resultStats"));
		System.out.println("result is    " + result.getText());

		return result.getText();

	}

	public static void clearSearchBox(String searchText) {
		WebElement searchBox = driver.findElement(By.id("lst-ib"));
		searchBox.clear();
		searchBox.sendKeys(searchText);
		clickOnSearhResultPage();

	}

	public static void clickOnSearhResultPage() {
		WebElement element = driver.findElement(By
				.xpath("//*[contains(@type,'submit')]"));
		element.click();

	}

	/*
	 * for (int i = 1; i <= 3; i++) { for (int j = i; j <= 3; j++) {
	 * System.out.println(sheet.getRow(i).getCell(j) .getStringCellValue());
	 * String check = sheet.getRow(i).getCell(3).getStringCellValue(); }
	 */

	public static void main(String args[]) throws AWTException {
		try {
			launchUrl(url);
			readExcel();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
