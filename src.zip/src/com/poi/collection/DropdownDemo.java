package com.poi.collection;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.testng.Assert;

public class DropdownDemo {
	static WebDriver driver;

	public static void hitUrl(String url) {

		System.setProperty(
				"webdriver.chrome.driver",
				"H:/Software/SeleniumHQ/Selenium WebDriver/Chrome Index of 2.3/chromedriver_win32/chromedriver.exe");
		// driver.manage().window().maximize();

		driver = new ChromeDriver();
		driver.navigate().to(url);
		driver.switchTo().alert().accept();
		driver.switchTo().alert().dismiss();
		driver.switchTo().alert().getText();

		driver.switchTo().alert().sendKeys("dhsdh");
		driver.manage().window().maximize();
		WebElement element = driver.findElement(By.id("gdgdfg"));
		element.getAttribute("name");
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();

			action.contextClick().perform();
		File src=  ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File("H:/seleniumrtye"+".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void selectDropdwonValue() {
		Select drpCountry = new Select(driver.findElement(By.name("country")));

		drpCountry.selectByVisibleText("ANTARCTICA");
		
		System.out.println(drpCountry.getFirstSelectedOption().getText());

		List<WebElement> list = drpCountry.getAllSelectedOptions();

		for (WebElement str : list) {
			System.out.println(str.getText());
		}

		// Selecting Items in a Multiple SELECT elements
		/*
		 * driver.get("http://jsbin.com/osebed/2"); Select fruits = new
		 * Select(driver.findElement(By.id("fruits")));
		 * fruits.selectByVisibleText("Banana"); fruits.selectByIndex(1);
		 */

	}

	public static void main(String[] args) {

		String url = "http://demo.guru99.com/test/newtours/register.php";
		hitUrl(url);

		selectDropdwonValue();
	}
}
