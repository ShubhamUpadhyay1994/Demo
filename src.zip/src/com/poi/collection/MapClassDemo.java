package com.poi.collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


public class MapClassDemo {

	public static void main(String args[]){
		 Map<Integer,String> map= new HashMap<Integer, String>();
		 map.put(1, "hello");
		 map.put(2, "tyuytrert");
		 map.put(34, "tyuy8798trert");
		 map.put(14, "tyuytrer564");
		 map.put(16, "tyuyt567");
		 
			System.out.println("2nd way to read map data using EntrySet");
			for (Entry<Integer, String> read : map.entrySet()) {
				System.out.println("Key -> " + read.getKey() + " value ->"
						+ read.getValue());
			}
			
			System.out.println("key set");
			for(Integer intr:map.keySet()){
				System.out.println("key is "+intr +"  value is  "+map.get(intr));
			}
		}
	
}
