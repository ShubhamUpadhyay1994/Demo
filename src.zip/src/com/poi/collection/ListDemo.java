package com.poi.collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListDemo {

	public static void main(String args[]) {

		LinkedList<String> list = new LinkedList<String>();
		list.add("RAm");
		list.add("Shyam");
		list.add("Hare");
		list.add("Krishna");
		Iterator<String> itr = list.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("get0 ---------------"+list.get(0));

		System.out.println("________________");
		for (String str : list) {
			System.out.println(str);
		}
		System.out.println(list.getLast());
		System.out.println(list.getFirst());
		System.out.println("get0"+list.get(0));

		System.out.println("____Array list____________");
		ArrayList<String> list1 = new ArrayList<String>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
		list1.add("Krishna");
		
		/*list.removeAll(list1);
		for(String rty:list){
			System.out.println(rty);
			
		}*/
	}
}
