package com.poi.collection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;

public class ReadExcelDemoJavatpoint {

	private static XSSFWorkbookType file1;

	public static void main(String args[]) {

		try {
			FileInputStream file = new FileInputStream(new File("H:/ThingsToDo.xslx"));
	

		// create workbook instance holding reference to .xlsx file
		XSSFWorkbook workbook = new XSSFWorkbook(file);

		XSSFSheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();

				//// Check the cell type and format accordingly

				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					System.out.println(cell.getNumericCellValue() + "t");
					break;
				case Cell.CELL_TYPE_STRING:
					System.out.println(cell.getStringCellValue());
					break;
				}
				
				//System.out.println(cell.getStringCellValue());
			}
			System.out.println(" ");
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		
			e.printStackTrace();
		}

	finally{
		System.out.println("finally bloxk");
	}
}

}