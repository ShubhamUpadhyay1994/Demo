package com.poi.collection;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class LastExcelRead {

	public static void main(String args[]) throws IOException {

		File file = new File("H:/KTPlan.xlsx");
		FileInputStream fileInput = new FileInputStream(file);

		XSSFWorkbook workbook = new XSSFWorkbook(fileInput);
		// XSSFSheet sh=workbook.getSheetAt(0);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int row = sheet.getPhysicalNumberOfRows();
		int column = sheet.getRow(0).getPhysicalNumberOfCells();
		for (int i = 0; i < row; i++) {

			XSSFRow row1 = sheet.getRow(i);
			if (row1 != null)
				for (int j = 0; j < column; j++) {

					XSSFCell cell = row1.getCell(j);
					if (cell != null)
						System.out.print(cell);
				}
			System.out.println(" ");

		}

	}

}
