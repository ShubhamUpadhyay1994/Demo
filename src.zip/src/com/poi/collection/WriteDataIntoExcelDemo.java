package com.poi.collection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteDataIntoExcelDemo {

	public static void main(String args[]) throws IOException {

		ArrayList<String> friends = new ArrayList<String>();
		friends.add("Hare");
		friends.add("Hare");
		friends.add("alok");
		friends.add("pawan");
		friends.add("ramanand");
		friends.add("afghggh");
		friends.add("dfdsgfh");
		friends.add("fdsfgdgfdghgdh");

		Map<String, Object[]> data = new TreeMap<String, Object[]>();

		data.put("1", new Object[] { "ID", "Name", "Lastname" });
		data.put("2", new Object[] { "1", "Shubham", "Upadhyay" });
		data.put("3", new Object[] { "3", "Ajay", "SIngh" });

		Set<String> setKey = data.keySet();
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("friends.xlsx");
		int row = 0, column = 0;
		for (String key : setKey) {
			Row createRow = sheet.createRow(++row);
			Object[] objArr = data.get(key);
			for (Object m : objArr) {
				Cell cell = createRow.createCell(++column);
				cell.setCellValue((String) m);
			}
		}
		FileOutputStream out = new FileOutputStream(new File("H:/friends.xlsx"));
		workbook.write(out);
		System.out.println("file is written");
	}
}
