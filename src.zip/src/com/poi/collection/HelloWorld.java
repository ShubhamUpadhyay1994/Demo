package com.poi.collection;
import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class HelloWorld {
	static WebDriver driver;

	public static void launchDriver(String url) {
		System.setProperty("webdriver.ie.driver","H:/Software/SeleniumHQ/Selenium WebDriver/2.53/IEDriverServer.exe");
	//	driver = new ChromeDriver();
		driver= new InternetExplorerDriver();
		driver.navigate().to(url);
	}

	public static void assertAndVerify() {
		// WebElement element = driver.findElement(By.id("lst-ib"));
		String title = "Online Shopping Fashion, Books, Electronics, Home Appliances and More";
		String getTile = driver.getTitle();
		System.out.println("Title++++++++++++++++" + getTile);
		org.testng.Assert.assertEquals(title, getTile);

	}

	public static void hoverOverAnElement() {
		WebElement element = driver.findElement(By.className("logo-li-mob"));
		WebElement product = driver.findElement(By.cssSelector("a[title='more about products']"));
		Actions action = new Actions(driver);
		action.moveToElement(product);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement compareProduct = driver.findElement(By.linkText("Compare Products"));
		wait.until(ExpectedConditions.visibilityOf(compareProduct));
		compareProduct.click();
	}

	public static void iFrameDemo() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2000)");
		int size = driver.findElements(By.tagName("iframe")).size();
		System.out.println("frame in page " + size);

		driver.switchTo().frame("a077aa5e");
		System.out.println("switch to frame+++++++++++++++++++++++");
		// driver.findElement(By.xpath("html/body/a/img")).click();
		String parent = driver.getWindowHandle();
		driver.findElement(By.cssSelector("img[src='Jmeter720.png']")).click();
		Set<String> childWindow = driver.getWindowHandles();// Return a set of
															// window handle
		driver.switchTo().window(parent);
		String winHandle = childWindow.iterator().next();
		driver.switchTo().window(winHandle);

		driver.switchTo().defaultContent();

		try {
			takeSnapShot(driver, "c://test.png");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void takeSnapShot(WebDriver webdriver, String fileWithPath) throws Exception {

		// Convert web driver object to TakeScreenshot

		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);

		// Call getScreenshotAs method to create image file

		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

		// Move image file to new destination

		File DestFile = new File(fileWithPath);

		// Copy file at destination

		FileUtils.copyFile(SrcFile, DestFile);

	}

	public static void captureScreenShot(WebDriver driver, String fileDest) {

		// Convert webdriver to takeScreenshot
		TakesScreenshot scrShot = (TakesScreenshot) driver;
		// Call method to take screenshot and store into file
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		// created destination file to store image screenshot
		File DestFiles = new File(fileDest + "Scrrenshot" + System.currentTimeMillis() + ".png");

		try {
			// Copy screenshot into destination file
			FileUtils.copyFile(srcFile, DestFiles);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		/*
		 * // Take screenshot and store as a file format File
		 * src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		 * 
		 * 
		 * try { // now copy the screenshot to desired location using copyFile
		 * method
		 * 
		 * FileUtils.copyFile(src, new
		 * File("H:/selenium/"+System.currentTimeMillis()+".png")); } catch
		 * (IOException e){ System.out.println(e.getMessage()); }
		 */
	}

	public static void main(String args[]) {
		String url = "http://demo.guru99.com/test/guru99home/";
		String fileDest = "C:/Demo/";
		launchDriver(url);
	//captureScreenShot(driver, fileDest);
		iFrameDemo();
		//captureScreenShot(driver, fileDest);
	}

}
