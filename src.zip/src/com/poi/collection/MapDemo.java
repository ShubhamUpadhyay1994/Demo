package com.poi.collection;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String args[]){
		
		HashMap<Integer,String> hashmap=new HashMap<Integer,String>();
		hashmap.put(1, "First package is for 5 lacs");
		hashmap.put(2, "2nd package is for 5.5 lacs");
		hashmap.put(3, "3rd package is for 6 lacs");
		hashmap.put(null, "First package is for 567 lacs");
		hashmap.put(null, "First package is for 565 lacs");
		hashmap.put(null, "First package is for 875 lacs");
		hashmap.put(23,null);
		hashmap.put(24, null);
		for(Map.Entry hs:hashmap.entrySet()){
			System.out.println(hs.getKey()+" "+hs.getValue());
		}
		
		System.out.println(hashmap.get(null));
		
		System.out.println("------LinkedHashMap-------------");
		LinkedHashMap<Integer,String> linked=new LinkedHashMap<>();
		linked.put(1,"Ram");
		linked.put(2, "Krishna");
		linked.put(3,"Shiv");
		
		linked.put(null, "First package is for 5 lacs");
		linked.put(null, "First package is for 675 lacs");
		
		linked.put(4,null);
		linked.put(5,null);
		for(Map.Entry hs:linked.entrySet()){
			System.out.println(hs.getKey()+" "+hs.getValue());
		}
		
		System.out.println("=====TreeMap========");
		TreeMap<Integer,String>tree= new TreeMap<>();
		tree.put(9, "CG");
		tree.put(2, "TCS");
		tree.put(5, "BNP");
		for(Map.Entry hs:tree.entrySet()){
			System.out.println(hs.getKey()+" "+hs.getValue());
		}
		
		System.out.println("____________Hashtable_____________");
		Hashtable<Integer, String> hash=new Hashtable<Integer, String>();
		hash.put(1, "12th");
		hash.put(2, "10th");
		hash.put(3,"BSC");
		hash.put(4,"MMM");
		hash.put(7,"vvv");
		hash.put(8, null);
		for(Map.Entry hs:hash.entrySet()){
			System.out.println(hs.getKey()+" "+hs.getValue());
		}
		Collection<String> collection = (Collection<String>) new MapDemo();
		
		
	}
	
	
}
