package com.poi.collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String args[]){
		System.out.println("__________HashSet__________");
		HashSet<Integer> set=new HashSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(5678);
		
		
		Iterator<Integer> itr= set.iterator();
	
		while(itr.hasNext())
		{System.out.println(itr.next());
		}	
		
		set.remove(3);
		Iterator<Integer> itr1= set.iterator();
		
		while(itr1.hasNext())
		{System.out.println(itr1.next());
		}	
		
		System.out.println("__________LinkedHashSet__________");
		
		LinkedHashSet<Float> linked = new LinkedHashSet<Float>();
		linked.add((float) 12);
		linked.add((float) 13.0);
		linked.add((float) 56.0);
		for(float t:linked){
			System.out.println("======="+t);
		}
		System.out.println("__________TreeSet__________");
	
		TreeSet<Character> treeSet=new TreeSet<>();
		treeSet.add('p');
		treeSet.add('n');
		treeSet.add('o');
		for(char f:treeSet)
		{
			System.out.println("^^^^^^^^^^^^^^^"+f);
		}
		
		
		
		}
	}

