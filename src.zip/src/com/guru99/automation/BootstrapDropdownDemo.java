package com.guru99.automation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.interactions.touch.Scroll;

public class BootstrapDropdownDemo {
	static WebDriver driver;

	public static void setProperty(String url) {

		System.setProperty(
				"webdriver.chrome.driver",
				"H:/Software/SeleniumHQ/Selenium WebDriver/Chrome Index of 2.3/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to(url);
		
		System.out.println("driver.getCurrentUrl()"+driver.getCurrentUrl());
		System.out.println("driver.getTitle()"+driver.getTitle());
		//System.out.println("pagesource "+driver.getPageSource());
		System.out.println("getclass"+driver.getClass());
	}

	public static void clickOnDropdown() {
		WebElement element = driver.findElement(By
				.xpath("//button[@id='menu1']"));
		element.click();
	}

	public static void selectValueFromDropdownExample() {
		JavascriptExecutor js= (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0.600)");
		List<WebElement> list = driver.findElements(By
				.xpath("//ul[@class='dropdown-menu']//li/a"));
		for (WebElement ele : list) {
			System.out.println(ele.getAttribute("innerHTML"));

			if (ele.getAttribute("innerHTML").contains("JavaScript")) {
				ele.click();
				//break;
			}
		}

	}

	public static void main(String[] args) throws InterruptedException {

		String url = "http://seleniumpractise.blogspot.in/2016/08/bootstrap-dropdown-example-for-selenium.html";
		setProperty(url);
		clickOnDropdown();
	//	Thread.sleep(2000);
		selectValueFromDropdownExample();

	}

}
