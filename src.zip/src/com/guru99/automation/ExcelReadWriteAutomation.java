package com.guru99.automation;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadWriteAutomation {

	public static void main(String args[]) throws InvalidFormatException,
			IOException {
		readExcel();
	}

	static void readExcel() throws InvalidFormatException, IOException {
		FileInputStream file = new FileInputStream(new File(
				"H:/candidateSheet.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
System.out.println(" hellow");
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rows = sheet.getPhysicalNumberOfRows();

		for (int i = 0; i <= rows; i++) {
			Row row = sheet.getRow(i);
			if (row != null) {
				int column = row.getPhysicalNumberOfCells();
				for (int j = 0; j <= column; j++) {
					Cell cell = row.getCell(j);
					if (cell != null)
						System.out.println(cell.getStringCellValue());

				}

			}
		}

	}
}
